const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();

const port = 5000;


app.use(express.json());
app.use(cors());

//get coordinates
//1. source 
//2. destination
const getCoordinates = async(address)=>{
   const response = await axios.get(`https://nominatim.openstreetmap.org/search`,{
     params:{
        q:address,
        format:'json',
     }
   })
   console.log("data",response.data)
    const {lat,lon} = response.data[0];
    return {lat,lon};
};

//distance
const getAStarDist = (coords1, coords2) => {
    const toRad = (x) => x * Math.PI / 180;
    
    const lat1 = parseFloat(coords1.lat);
    const lon1 = parseFloat(coords1.lon);
    const lat2 = parseFloat(coords2.lat);
    const lon2 = parseFloat(coords2.lon);

    const R = 6371; // Radius of the Earth in kilometers
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in kilometers

    return distance;
};




app.post('/route', async (req, res) => {
    console.log("finding distance")
    const{source,destination}=req.body;
    //source finding(lat, lon)
    // const s-cordinates = await getCords(address)
    // const d-cordinates = await getCords(address)
    // const distance = await getShortestDestance(s-cordinates, d-coditnates)
    //res.send(distance)
    try{
     const sourcecoordinates = await getCoordinates(source);
     const distinationcoordinates = await getCoordinates(destination);
    
     const distance = getAStarDist(sourcecoordinates,distinationcoordinates);
    console.log(distance)
    
     res.json({ distance });
    } catch(error){
        console.log(`error`,error.message)
    }


    
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
