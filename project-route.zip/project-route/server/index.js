const express = require('express');

const axios = require('axios');
const cors = require('cors');
const app = express();
const port = 4000;  

app.use(express.json());
app.use(cors());

//class
const getCoordinates = async (address) => {
  try {
    const response = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: {
        q: address,
        format: 'json',
      }
    });
    if (response.data.length === 0) {
      throw new Error(`No coordinates found for address: ${address}`);
    }
    const { lat, lon } = response.data[0];
    return { lat: parseFloat(lat), lon: parseFloat(lon) };
  } catch (error) {
    console.error('Error in getCoordinates:', error.message);
    throw error;
  }
};

const getRoute = async (sourceCoords, destCoords) => {
  const url = `http://router.project-osrm.org/route/v1/driving/${sourceCoords.lon},${sourceCoords.lat};${destCoords.lon},${destCoords.lat}?overview=full&geometries=geojson`;
  try {
    const response = await axios.get(url);
    const route = response.data.routes[0];
    //
    return {
      distance: route.distance / 1000, // Convert to km
      duration: route.duration / 60, // Convert to minutes
      geometry: route.geometry.coordinates.map(([lon, lat]) => ({ lat, lon }))
    };
  } catch (error) {
    console.error('Error in getRoute:', error.message);
    throw error;
  }
};

app.post('/route', async (req, res) => {
  const { source, destination } = req.body;
  console.log('Received request:', { source, destination });

  try {
    const sourceCoordinates = await getCoordinates(source);
    const destinationCoordinates = await getCoordinates(destination);
    console.log('Coordinates:', { sourceCoordinates, destinationCoordinates });

    const routeData = await getRoute(sourceCoordinates, destinationCoordinates);

    console.log('Route result:', routeData);
    res.json(routeData);
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});