import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Popup, useMap } from 'react-leaflet';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt, faFlag } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import 'leaflet/dist/leaflet.css';
import './App.css';

// This component will handle map updates
function MapUpdater({ routeData }) {
  const map = useMap();

  useEffect(() => {
    if (routeData && routeData.geometry.length > 0) {
      const bounds = routeData.geometry.reduce(
        (bounds, coord) => bounds.extend([coord.lat, coord.lon]),
        map.getBounds()
      );
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [map, routeData]);

  return null;
}

const App = () => {
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [routeData, setRouteData] = useState(null);
  const [mapCenter, setMapCenter] = useState([20.5937, 78.9629]); // Center of India
  const [mapZoom, setMapZoom] = useState(5);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setRouteData(null);
    setError(null);

    if (!source || !destination) {
      setError('Please enter both source and destination');
      return;
    }

    try {
      const response = await axios.post('http://localhost:4000/route', {
        source,
        destination
      });
      setRouteData(response.data);
    } catch (error) {
      console.error('Error fetching route:', error.response?.data?.error || error.message);
      setError('Error: ' + (error.response?.data?.error || error.message));
    }
  };

  return (
    <div className="container">
      <h1>Route Planner</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="source">
            <FontAwesomeIcon icon={faMapMarkerAlt} /> Source:
          </label>
          <input id="source" type="text" value={source} onChange={(e) => setSource(e.target.value)} required />
        </div>
        <div className="form-group">
          <label htmlFor="destination">
            <FontAwesomeIcon icon={faFlag} /> Destination:
          </label>
          <input id="destination" type="text" value={destination} onChange={(e) => setDestination(e.target.value)} required />
        </div>
        <button type="submit">Find Route</button>
      </form>
      {error && <p className="error">{error}</p>}
      {routeData && (
        <div className="results">
          <h2>Distance: {routeData.distance.toFixed(2)} km</h2>
          <h2>Duration: {routeData.duration.toFixed(2)} minutes</h2>
        </div>
      )}
      <div className="map-container">
        <MapContainer center={mapCenter} zoom={mapZoom} style={{ height: '100%', width: '100%' }}>
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          {routeData && routeData.geometry.length > 0 && (
            <>
              <Polyline positions={routeData.geometry.map(coord => [coord.lat, coord.lon])} color="blue" />
              <Marker position={[routeData.geometry[0].lat, routeData.geometry[0].lon]}>
                <Popup>
                  <FontAwesomeIcon icon={faMapMarkerAlt} style={{ color: '#4CAF50' }} /> Source
                </Popup>
              </Marker>
              <Marker position={[routeData.geometry[routeData.geometry.length - 1].lat, routeData.geometry[routeData.geometry.length - 1].lon]}>
                <Popup>
                  <FontAwesomeIcon icon={faFlag} style={{ color: '#F44336' }} /> Destination
                </Popup>
              </Marker>
              <MapUpdater routeData={routeData} />
            </>
          )}
        </MapContainer>
      </div>
    </div>
  );
};

export default App;
